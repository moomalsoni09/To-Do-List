const HomePage = (props) =>{
  const {name} = props;
  return(
    <>
    <h1>{name}</h1>
    <div style={{padding:"20px"}}>
    </div>
    </>
  );
};
export default HomePage;