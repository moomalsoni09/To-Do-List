function Footers(){
  return(
    <>
    <p>footer</p>
    </>
  );
}
export default Footers;